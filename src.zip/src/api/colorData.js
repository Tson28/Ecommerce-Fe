export const colorData = [
  {
    id: 1,
    name: "Đen",
  },
  {
    id: 2,
    name: "Vàng",
  },
  {
    id: 3,
    name: "Trắng ",
  },
  {
    id: 4,
    name: "Bạc",
  },
];
