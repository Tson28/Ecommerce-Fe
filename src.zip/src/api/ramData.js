export const ramData = [
  {
    id: 1,
    name: "4",
  },
  {
    id: 2,
    name: "8",
  },
  {
    id: 3,
    name: "16",
  },
  {
    id: 4,
    name: "32",
  },
];
