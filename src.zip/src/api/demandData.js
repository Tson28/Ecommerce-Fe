export const demandData = [
  {
    id: 1,
    name: "Gaming",
    value: "Gaming",
  },
  {
    id: 2,
    name: "Văn phòng",
    value: "Văn-phòng",
  },
  {
    id: 3,
    name: "Học sinh - Sinh viên",
    value: "Học-sinh-Sinh-viên",
  },
  {
    id: 4,
    name: "Đồ họa - Kỹ thuật",
    value: "Đồ-họa-kỹ-thuật",
  },
];
