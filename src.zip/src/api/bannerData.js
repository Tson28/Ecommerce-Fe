export const bannerData = [
  {
    id: "1",
    img: "https://lh3.googleusercontent.com/qj1ewOX6-3x_2ythkRnxLD0I_Mx1eXsr6zLzUnbFbBXh1r63uR_aON6mBXrJepDeWVAvMTTctCBbeCOz9u0sEVNPA5_OnBhf=rw-w1920",
  },
  {
    id: "2",
    img: "https://lh3.googleusercontent.com/Z9EKSE-M6wIGl2iCCx9iPjmD3BI8zYRY_braf8j3SVn22HwVzNSWyCPGtKgmjW3S64iZf9fkkBfI92BKvGKTcwqe0Vpnl97C=rw-w1920",
  },
  {
    id: "3",
    img: "https://lh3.googleusercontent.com/llRGlCgB6jJs9wq4fU4Rroz_rxn2xgfRjyXhLeeWnd7Fbpow0oo2Y2fE6YKPWjM9uDtXNtn5pDXOhXwzB79AaLBnCKfxeTOF=rw-w1920",
  },
  {
    id: "4",
    img: "https://lh3.googleusercontent.com/4l3CMJLcn5fke5-of95C06OBrNRYGPWih3wqeDCYfyXJN3EndmMkO1yRbI5ohylxaJhQ35j5fSTPNfZGQQGd1SwRbYJYp4Q=rw-w1920",
  },
  {
    id: "5",
    img: "https://lh3.googleusercontent.com/q4Knj3SkeQJeR8dyfilKzqMfuQyIkbRg8_y4ayyco5lNvYki_oSB8PCycwSj8Fqifcm8NpGJiEd48boGfLl5TGZaKqEYVTvb8g=rw-w1920",
  },
];
