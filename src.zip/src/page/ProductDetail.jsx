import React from "react";
import ProductInformation from "../module/product/ProductInformation";
const ProductDetail = () => {
  return (
    <div>
      <ProductInformation />
    </div>
  );
};

export default ProductDetail;
