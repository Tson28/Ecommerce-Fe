const StorageKeys = {
  USER: "user",
  TOKEN: "jwt",
};
export default StorageKeys;
