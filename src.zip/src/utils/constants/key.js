export const key = {
  ClientId:
    "Ac9P1q7pdUzNwDIvBSMIfkVM_dFCoGFaeCb3JqzJvs-ToFC41HOn9Iw0TILqp_aoKK4yvdvOYhshK38Y",
  REACT_APP_STREAM_API_KEY: "g5nrfaxhzxf2",
};
